/**
 * SERVER.JS - Serveur Node.js pour LegalShuffleCam
 * Intègre Express pour le HTTP, Socket.IO pour la signalisation WebRTC,
 * et la logique de Modération.
 */

const express = require('express');
const http = require('http'); // Requis pour Socket.IO
const fs = require('fs'); // Requis pour la journalisation de modération
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);

// Configuration des fichiers statiques et Healthcheck existants
app.use(express.static('public'));
app.get('/healthz', (_req, res) => res.type('text/plain').send('OK'));

// Configuration Socket.IO (Acceptation des connexions depuis n'importe quelle origine pour la simplicité)
const io = new Server(server, {
    cors: {
        origin: "*", 
        methods: ["GET", "POST"]
    }
});

const PORT = 3000; 

// ------------------------------------------------------------------
// --- LOGIQUE DE MODÉRATION (Base fournie par l'utilisateur) ---
// ------------------------------------------------------------------

const BAN_DURATION_MS = 24 * 60 * 60 * 1000;
const STRIKE_WINDOW_MS = 15 * 60 * 1000;
const STRIKES_TO_BAN = 2;

const bans = new Map();
const strikes = new Map();

function isBanned(maskedIp) {
  const exp = bans.get(maskedIp);
  if (!exp) return false;
  if (Date.now() > exp) { bans.delete(maskedIp); return false; }
  return true;
}

function addStrike(maskedIp) {
  const now = Date.now();
  const s = strikes.get(maskedIp) || {count:0, firstTs:now};
  if (now - s.firstTs > STRIKE_WINDOW_MS) { s.count = 0; s.firstTs = now; }
  s.count++;
  strikes.set(maskedIp, s);
  if (s.count >= STRIKES_TO_BAN) {
    bans.set(maskedIp, now + BAN_DURATION_MS);
    return { banned: true };
  }
  return { banned: false, strikes: s.count };
}

function logModeration(evt, maskedIp, extra = "") {
  // Remplace /var/log/legalshufflecam/ par un chemin simple si l'environnement de log est différent
  const logPath = '/var/log/legalshufflecam/moderation.log'; 
  const line = `${new Date().toISOString()},${evt},${maskedIp},${extra}\n`;
  try { fs.appendFile(logPath, line, ()=>{}); } catch (e) { console.error('Erreur de log:', e); }
}


// ------------------------------------------------------------------
// --- LOGIQUE DE MATCHMAKING ET SIGNALISATION (WebRTC) ---
// ------------------------------------------------------------------

let usersQueue = []; 
let pairedUsers = {}; // { [socketId]: partnerSocketId }

function getPartnerId(socketId) {
    return pairedUsers[socketId] || null;
}

function cleanupUser(socketId) {
    usersQueue = usersQueue.filter(id => id !== socketId);
    
    const partnerId = pairedUsers[socketId];
    if (partnerId) {
        delete pairedUsers[socketId];
        delete pairedUsers[partnerId];
    }
    return partnerId;
}


io.on('connection', (socket) => {
    console.log(`[CONN] Utilisateur connecté: ${socket.id}`);
    
    // Ajoute l'IP masquée au socket pour les fonctions de modération/log
    // NOTE: socket.handshake.address est l'adresse de la connexion HTTP (peut être un proxy)
    const maskedIp = socket.handshake.address; 
    
    // --- Événement : REPORT ---
    socket.on('report-user', () => {
        const partnerId = getPartnerId(socket.id);
        
        if (partnerId) {
            // Le serveur doit notifier le partenaire (qui est reporté)
            io.to(partnerId).emit('was-reported');
            
            // Le serveur prend l'IP du partenaire pour le bannissement
            const partnerSocket = io.sockets.sockets.get(partnerId);
            const partnerMaskedIp = partnerSocket ? partnerSocket.handshake.address : 'unknown';
            
            const result = addStrike(partnerMaskedIp);
            logModeration('REPORTED', partnerMaskedIp, `Reporter: ${maskedIp}, Partner: ${partnerId}`);
            
            if (result.banned) {
                console.log(`[BAN] Utilisateur ${partnerId} banni.`);
                // Envoyer un événement forçant la déconnexion si banni
                io.to(partnerId).emit('force-disconnect', 'banned');
            }
        }
    });


    // --- Événement : JOIN QUEUE / MATCHING ---
    socket.on('joinQueue', () => {
        if (isBanned(maskedIp)) {
            socket.emit('force-disconnect', 'banned');
            return;
        }

        cleanupUser(socket.id);
        
        if (usersQueue.length > 0) {
            const partnerId = usersQueue.shift(); 
            
            // Vérification de la validité et du statut de ban du partenaire
            const partnerSocket = io.sockets.sockets.get(partnerId);
            const partnerMaskedIp = partnerSocket ? partnerSocket.handshake.address : 'unknown';

            if (!partnerSocket || isBanned(partnerMaskedIp)) {
                console.warn(`[MATCH] Partenaire en file d'attente invalide ou banni. Réessayons.`);
                usersQueue.push(socket.id);
                socket.emit('waiting');
                return;
            }

            // Mettre à jour le partenariat
            pairedUsers[socket.id] = partnerId;
            pairedUsers[partnerId] = socket.id;

            console.log(`[MATCH] Appariement trouvé: ${socket.id} <-> ${partnerId}`);

            // Notifier l'appelant (Offreur)
            socket.emit('matched', true); 

            // Notifier le partenaire (Receveur)
            partnerSocket.emit('matched', false);
        } else {
            // Ajouter à la file
            usersQueue.push(socket.id);
            console.log(`[MATCH] Utilisateur ${socket.id} mis en attente.`);
            socket.emit('waiting');
        }
    });

    // --- Événement : SIGNALISATION WEB-RTC ---
    
    const relaySignal = (eventName, data) => {
        const partnerId = getPartnerId(socket.id);
        if (partnerId) {
            io.to(partnerId).emit(eventName, data); 
        }
    };

    socket.on('offer', (offer) => { relaySignal('offer', offer); });
    socket.on('answer', (answer) => { relaySignal('answer', answer); });
    socket.on('ice-candidate', (candidate) => { relaySignal('ice-candidate', candidate); });

    
    // --- Événement : DÉCONNEXION ---
    socket.on('disconnect', () => {
        console.log(`[CONN] Utilisateur déconnecté: ${socket.id}`);
        
        const partnerId = cleanupUser(socket.id);
        
        if (partnerId) {
            // Notifier le partenaire
            io.to(partnerId).emit('partner-disconnected');
            console.log(`[DISCO] Partenaire ${partnerId} notifié.`);
            
            // Tenter de remettre le partenaire en file d'attente
            const partnerSocket = io.sockets.sockets.get(partnerId);
            if (partnerSocket) {
                cleanupUser(partnerId); 
                usersQueue.push(partnerId); 
                partnerSocket.emit('waiting');
                console.log(`[DISCO] Partenaire ${partnerId} remis en file d'attente.`);
            }
        }
    });
});


// Démarrage du serveur HTTP/Socket.IO
server.listen(PORT, () => {
    console.log(`[SERVER] LegalShuffleCam Server démarré sur le port ${PORT}`);
    console.log(`[SERVER] Le serveur Socket.IO est prêt.`);
});

// module.exports = app; // Remplacé par l'écoute directe pour simplifier
