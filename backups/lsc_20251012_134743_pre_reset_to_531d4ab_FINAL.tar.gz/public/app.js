/**
 * APP.JS - Logique principale de Socket.IO et WebRTC pour LegalShuffleCam.
 * Encapsule les connexions pour permettre le redémarrage via 'Interlocuteur suivant'.
 * NOTE : La gestion de l'UI (bouton, topBar) est maintenant dans index-real.php.
 */

// Variables globales pour le nettoyage (partagées avec index-real.php)
let socket = null;
let peerConnection = null;
// Utilisation du STUN de Google, standard pour WebRTC
const ICE_SERVERS = [{ 'urls': 'stun:stun.l.google.com:19302' }]; 

// Récupération des éléments DOM pour la mise à jour (Sécurité contre l'écrasement de l'UI par index-real.php)
const remoteVideo = document.getElementById('remoteVideo');
const topBar = document.getElementById('topBar');
const btnNext = document.getElementById('btnNext');
const btnReport = document.getElementById('btnReport'); // Récupération du bouton Report

// ----------------------------------------------------
// LOGIQUE DE SIGNALEMENT (REPORT) - Écouteur de clic permanent
// ----------------------------------------------------
if (btnReport) {
    btnReport.addEventListener('click', () => {
        if (socket && socket.connected) {
            console.log('[REPORT] Envoi du signalement...');
            // 1. Envoyer le signalement au serveur
            socket.emit('report-user');
            
            // 2. Feedback utilisateur immédiat et appel de nextInterlocutor (qui déconnecte/reconnecte)
            btnReport.textContent = 'Signalé ! (Déconnexion)';
            // Utiliser setTimeout pour s'assurer que l'événement socket part avant la déconnexion
            setTimeout(window.nextInterlocutor, 100); 
        }
    });
}
// Fin LOGIQUE DE SIGNALEMENT


/**
 * 1. Ferme la connexion WebRTC et Socket.IO existantes.
 * Appelée par le bouton 'Interlocuteur suivant' dans index-real.php.
 */
window.disconnectWebRTC = function() {
    console.log('[LSC:Disconnect] Déconnexion en cours...');
    
    // 1. Fermer la connexion WebRTC
    if (peerConnection) {
        peerConnection.close();
        peerConnection = null;
        console.log('[LSC:Disconnect] WebRTC closed.');
    }
    
    // 2. Fermer la connexion Socket.IO
    if (socket && socket.connected) {
        socket.close();
        socket = null;
        console.log('[LSC:Disconnect] Socket.IO closed.');
    }
}

/**
 * 2. Établit la nouvelle connexion Socket.IO et WebRTC.
 * @param {MediaStream} localStream - Le flux vidéo/audio de la caméra locale (fourni par index-real.php).
 * Appelée au chargement initial et au clic sur 'Interlocuteur suivant'.
 */
window.connectSocketAndWebRTC = function(localStream) {
    
    // Sécurité: Assurer le nettoyage de toute connexion précédente
    window.disconnectWebRTC();

    console.log('[LSC:Connect] Démarrage de la connexion Socket.IO et WebRTC...');
    if (topBar) topBar.textContent = "🔄 Recherche d'un partenaire...";
    
    // Réinitialiser le texte du bouton de signalement
    if (btnReport) btnReport.textContent = 'Signaler'; 
    
    // Initialisation de la connexion Socket.IO
    socket = io();
    
    socket.on('connect', () => {
        console.log('[Socket.IO] Connecté au serveur. Demande de file d\'attente...');
        if (topBar) topBar.textContent = "🤝 Connecté. Envoi de la demande de match...";

        // 1. Demander au serveur de nous mettre en file d'attente
        socket.emit('joinQueue'); 
        
        // 2. Initialiser la connexion Peer-to-Peer (WebRTC)
        peerConnection = new RTCPeerConnection({ iceServers: ICE_SERVERS });

        // Ajouter le stream local à la connexion
        localStream.getTracks().forEach(track => {
            peerConnection.addTrack(track, localStream);
        });

        // Gestion de la réception de la piste distante
        peerConnection.ontrack = (event) => {
            console.log('[WebRTC] Piste distante reçue. Affichage de la vidéo.');
            if (remoteVideo) remoteVideo.srcObject = event.streams[0];
            if (topBar) topBar.textContent = "✅ Partenaire connecté !";
        };

        // Événement ICE Candidate : envoi de l'information de connectivité au pair
        peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                // Envoi de l'ICE Candidate au serveur pour le relayer au pair
                socket.emit('ice-candidate', event.candidate);
            }
        };

        // ----------------------------------------------------
        // LOGIQUE D'ÉCHANGE DE SIGNALISATION (OFFERS/ANSWERS)
        // ----------------------------------------------------
        
        // Événement 'waiting' : Le serveur a bien reçu la demande
        socket.on('waiting', () => {
             console.log('[MATCH] En attente d\'un partenaire...');
             if (topBar) topBar.textContent = 'Recherche d\'un partenaire en cours...';
        });

        // Événement 'matched' : le serveur a trouvé un pair
        socket.on('matched', async (isCaller) => {
            console.log('[MATCH] Partenaire trouvé ! Suis-je l\'appelant ?', isCaller);
            
            if (isCaller) {
                // Je suis l'appelant (Offreur)
                const offer = await peerConnection.createOffer();
                await peerConnection.setLocalDescription(offer);
                console.log('[WebRTC] Envoi de l\'Offer...');
                socket.emit('offer', peerConnection.localDescription);
            }
        });

        // Événement 'offer' reçu : Je suis le Receveur
        socket.on('offer', async (offer) => {
            console.log('[WebRTC] Offer reçue. Création de l\'Answer...');
            await peerConnection.setRemoteDescription(new RTCSessionDescription(offer));
            const answer = await peerConnection.createAnswer();
            await peerConnection.setLocalDescription(answer);
            socket.emit('answer', peerConnection.localDescription);
        });

        // Événement 'answer' reçu : Je suis l'Offreur, le pair a répondu
        socket.on('answer', async (answer) => {
            console.log('[WebRTC] Answer reçue.');
            await peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
        });

        // Événement 'ice-candidate' reçu
        socket.on('ice-candidate', async (candidate) => {
            try {
                // S'assurer que la description distante est définie avant d'ajouter le candidat
                if (peerConnection.remoteDescription) {
                    await peerConnection.addIceCandidate(candidate);
                }
            } catch (e) {
                // Cette erreur est souvent normale si le candidat est invalide ou déjà traité
                console.error('Erreur lors de l\'ajout de l\'ICE Candidate', e);
            }
        });
        
        // Événement de déconnexion du partenaire (via le serveur)
        socket.on('partner-disconnected', () => {
            console.log('[Socket.IO] Le partenaire s\'est déconnecté. Redémarrage du matching...');
            if (topBar) topBar.textContent = "⚠️ Partenaire déconnecté. Recherche d'un nouveau...";
            
            // Redémarre automatiquement la connexion après un court délai
            window.disconnectWebRTC(); 
            setTimeout(() => {
                window.connectSocketAndWebRTC(localStream);
            }, 3000); 
        });

        // ----------------------------------------------------
        // Événements spécifiques de MODÉRATION/REPORT
        // ----------------------------------------------------
        
        // 1. Événement reçu lorsqu'un utilisateur est signalé par son partenaire
        socket.on('was-reported', () => {
            console.log('[MODERATION] Vous avez été signalé. Redémarrage du match...');
            if (topBar) topBar.textContent = '⚠️ Vous avez été signalé. Recherche d\'un nouveau...';
            
            // Appeler la fonction qui gère la déconnexion et la relance du match
            window.nextInterlocutor();
        });

        // 2. Événement reçu lorsqu'un utilisateur est banni (déconnexion forcée)
        socket.on('force-disconnect', (reason) => {
             console.log('[MODERATION] Déconnexion forcée reçue:', reason);
            if (reason === 'banned') {
                 // Bloque l'interface utilisateur et affiche un message permanent (jusqu'à rechargement)
                 if (topBar) topBar.textContent = '🚫 Vous avez été banni du service pour 24 heures.';
                 if (btnNext) btnNext.disabled = true;
                 if (btnReport) btnReport.disabled = true;

                 // Arrête toute nouvelle tentative de connexion
                 window.disconnectWebRTC(); 
                 
                 // Afficher une alerte
                 alert('🚫 Vous avez été banni du service pour 24 heures en raison de signalements répétés.');
            }
        });

    }); // Fin socket.on('connect')
    
    // Gestion des erreurs Socket.IO (déconnexion inattendue)
    socket.on('disconnect', (reason) => {
        console.warn('[Socket.IO] Déconnecté du serveur :', reason);
        if (topBar) topBar.textContent = "🔴 Déconnecté. Tentative de reconnexion...";
        
        // La librairie socket.io tente de se reconnecter automatiquement si ce n'est pas une déconnexion volontaire
    });
} // Fin window.connectSocketAndWebRTC
